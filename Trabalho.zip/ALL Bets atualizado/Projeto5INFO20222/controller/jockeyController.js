const Jockey = require("../model/Jockey");

function abreadd(req, res) {
  res.render("jockey/add");
}

function add(req, res) {
  let jockey = new Jockey(
    /*req.body*/ {
      nome: req.body.nome,
      email: req.body.email,
      celular: req.body.senha,
      cpf: req.body.cpf,
      foto: req.file.filename,
    }
  );

  jockey.save(function (err) {
    if (err) {
      console.log(err);
    } else {
      res.redirect("/admin/jockey/lst");
    }
  });
}

function list(req, res) {
  Jockey.find({}, function (err, jockeys) {
    res.render("jockey/lst", { Jockeys: jockeys });
  });
}

function filtro(req, res) {
  Jockey.find(
    { nome: new RegExp(req.body.pesquisar, "i") },
    function (err, jockeys) {
      res.render("jockey/lst", { Jockeys: jockeys });
    }
  );
}

function del(req, res) {
  Jockey.findByIdAndDelete(req.params.id, function (err, jockeys) {
    res.redirect("/admin/jockey/lst");
  });
}

function abreedt(req, res) {
  Jockey.findById(req.params.id, function (err, jockey) {
    res.render("jockey/edt", { Jockey: jockey });
  });
}

function edt(req, res) {
  Jockey.findByIdAndUpdate(
    req.params.id,
    {
      nome: req.body.nome,
      email: req.body.email,
      celular: req.body.celular,
      cpf: req.body.cpf,
      foto: req.file.filename,
    },
    function (err, jockey) {
      res.redirect("/admin/jockey/lst");
    }
  );
}

module.exports = {
  abreadd,
  add,
  list,
  filtro,
  abreedt,
  edt,
  del,
};
