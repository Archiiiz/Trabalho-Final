const Cavalo = require('../model/Cavalo');

function abreadd(req, res) {
  res.render('cavalo/add');
}

function add(req, res) {
  let cavalo = new Cavalo(
    /*req.body*/ {
      placa: req.body.placa,
      marca: req.body.marca,
      ano: req.body.ano,
      modelo: req.body.modelo,
      dono: req.body.dono,
      foto: req.file.filename,
    }
  );

  cavalo.save(function (err) {
    if (err) {
      console.log(err);
    } else {
      res.redirect('/admin/cavalo/lst');
    }
  });
}

function list(req, res) {
  Cavalo.find({}, function (err, cavalos) {
    res.render('cavalo/lst', { Cavalos: cavalos });
  });
}

function filtro(req, res) {
  Cavalo.find(
    { nome: new RegExp(req.body.pesquisar, 'i') },
    function (err, cavalos) {
      res.render('cavalo/lst', { Cavalos: cavalos });
    }
  );
}

function del(req, res) {
  Cavalo.findByIdAndDelete(req.params.id, function (err, cavalos) {
    res.redirect('/admin/cavalo/lst');
  });
}

function abreedt(req, res) {
  Cavalo.findById(req.params.id, function (err, cavalo) {
    res.render('cavalo/edt', { Cavalo: cavalo });
  });
}

function edt(req, res) {
  Cavalo.findByIdAndUpdate(
    req.params.id,
    {
      placa: req.body.placa,
      marca: req.body.marca,
      ano: req.body.ano,
      modelo: req.body.modelo,
      dono: req.body.dono,
      foto: req.file.filename,
    },
    function (err, cavalo) {
      res.redirect('/admin/cavalo/lst');
    }
  );
}

module.exports = {
  abreadd,
  add,
  list,
  filtro,
  abreedt,
  edt,
  del,
};
