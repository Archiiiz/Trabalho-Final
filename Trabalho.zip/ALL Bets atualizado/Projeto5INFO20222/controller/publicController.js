const Cliente = require("../model/Cliente");
function abreindex(req, res) {
  Cliente.find({})
    .populate("cavalo")
    .populate("jockey")
    .exec(function (err, clientes) {
      res.render("public/index", { Clientes: clientes });
    });
}

module.exports = {
  abreindex,
};
