const express = require('express');
const router = express.Router();
const upload = require('../config/upload');

const jockeyController = require('../controller/jockeyController');

router.get('/jockey/add', jockeyController.abreadd);
router.post('/jockey/add', upload.single('foto'), jockeyController.add);
router.get('/jockey/lst', jockeyController.list);
router.post('/jockey/lst', jockeyController.filtro);
router.get('/jockey/edt/:id', jockeyController.abreedt);
router.post('/jockey/edt/:id', upload.single('foto'), jockeyController.edt);
router.get('/jockey/del/:id', jockeyController.del);

module.exports = router;
