const express = require('express');
const router = express.Router();
const upload = require('../config/upload');

const cavaloController = require('../controller/cavaloController');

router.get('/cavalo/add', cavaloController.abreadd);
router.post('/cavalo/add', upload.single('foto'), cavaloController.add);
router.get('/cavalo/lst', cavaloController.list);
router.post('/cavalo/lst', cavaloController.filtro);
router.get('/cavalo/edt/:id', cavaloController.abreedt);
router.post('/cavalo/edt/:id', upload.single('foto'), cavaloController.edt);
router.get('/cavalo/del/:id', cavaloController.del);

module.exports = router;
