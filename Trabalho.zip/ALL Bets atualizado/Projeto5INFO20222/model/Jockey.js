const mongoose = require('../config/conexao');

const jockeySchema = new mongoose.Schema({
  nome: String,
  email: String,
  celular: String,
  cpf: String,
  foto: String,
});

const jockey = mongoose.model('jockey', jockeySchema);

module.exports = jockey;
