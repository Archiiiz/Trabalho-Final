const mongoose = require('../config/conexao');

const cavaloSchema = new mongoose.Schema({
  placa: String,
  marca: String,
  ano: String,
  modelo: String,
  dono: String,
  foto: String,
});

const cavalo = mongoose.model('cavalo', cavaloSchema);

module.exports = cavalo;
