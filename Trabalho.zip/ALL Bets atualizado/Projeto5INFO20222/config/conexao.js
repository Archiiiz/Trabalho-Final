const mongoose = require('mongoose');
const banco = "mongodb://Archi:kwbsibdujsv@ac-ktjnnts-shard-00-00.hteu4wm.mongodb.net:27017,ac-ktjnnts-shard-00-01.hteu4wm.mongodb.net:27017,ac-ktjnnts-shard-00-02.hteu4wm.mongodb.net:27017/?ssl=true&replicaSet=atlas-64iwbi-shard-0&authSource=admin&retryWrites=true&w=majority";
mongoose.connect(banco, { useNewUrlParser: true, useUnifiedTopology: true });

module.exports = mongoose;
